export default function MainPage() {
    return <div>Main Page</div>;
  }
  