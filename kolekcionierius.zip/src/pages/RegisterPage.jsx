export default function RegisterPage() {
    return <div>Register Page</div>;
  }
  